#Nela vou criar os métodos que minha aplicação vai executar
from app import app
@app.route("/uc")
def listar_uc():
    return "Listar Unidades de Competências"