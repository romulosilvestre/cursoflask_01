from app import db

class UnidadeCompetencia(db.Model):
    #NOTE: encapsulamento no Python
    #se for __ (dois undescore) - private
    #se for _ (um undescore) - protected
    #se não tem - public

    __tablename__ = "unidadecompetencia"
    id = db.Column(db.Integer,primary_key=True,autoincrement=True)
    numero = db.Column(db.Integer)
    nome = db.Column(db.String(200))
    carga_horaria = db.Column(db.Integer,primary_key=True,autoincrement=True)
    competencia_geral= db.Column(db.Integer,primary_key=True,autoincrement=True)
    