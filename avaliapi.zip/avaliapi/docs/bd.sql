CREATE DATABASE projectscore;
USE projectscore;
CREATE TABLE curso (
    id int PRIMARY KEY auto_increment,
    nome varchar(80) NOT NULL
);
show tables;
describe curso;

