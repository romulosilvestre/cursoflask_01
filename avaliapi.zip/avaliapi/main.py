#NOTE: Habilidade 1- importar o flask e o sqlalchemy
from flask import Flask
import sqlalchemy

#NOTE: Habilidade 2 - instânciar o objeto app da classe Flask __name__ recebe como padrão o nome do projeto
app = Flask(__name__)

#NOTE: Habilidade 3 - definir rotas e cria-las, acessando e entendendo o seu funcionamento
@app.route("/")
def hello_world():
    return "<p>Project Score</p>"
@app.route("/times")
def lista_times():
    return "<p>Times Participantes</p>"

@app.route("/sobre")
def mostrar_sobre():
    return "<p> Flask é um microframework web escrito em Python de fácil utilização e de recursos incríveis </p>"

@app.route("/versoes")
def mostrar_versoes():
    return f"SQLAlchemy:{sqlalchemy.__version__}  <a href='https://docs.sqlalchemy.org/en/20/tutorial/index.html#unified-tutorial'>doc</a>"

#NOTE: Habilidade 4 - executar o aplicativo
app.run()

